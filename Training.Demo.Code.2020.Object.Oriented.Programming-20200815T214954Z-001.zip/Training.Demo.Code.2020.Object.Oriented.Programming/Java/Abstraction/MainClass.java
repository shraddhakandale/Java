public class MainClass {

    public static void main(String args[]) {
        Camera camera = new Camera();
        // User only knows camera can click picture. User does not know how it does that.
        camera.clickPicture();
    }
}
