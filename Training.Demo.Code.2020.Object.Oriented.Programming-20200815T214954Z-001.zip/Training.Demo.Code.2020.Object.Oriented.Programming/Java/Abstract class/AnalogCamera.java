// Concrete class
public class AnalogCamera extends Camera {

    @Override
    public void savePicture() {
        System.out.println("Saving picture to Film.");
    }
}
