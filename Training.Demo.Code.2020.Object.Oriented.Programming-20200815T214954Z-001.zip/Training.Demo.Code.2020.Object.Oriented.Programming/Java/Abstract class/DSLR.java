// Concrete class
public class DSLR extends DigitalCamera {

    @Override
    public void savePicture() {
        System.out.println("Saving picture to SD card.");
    }
}
