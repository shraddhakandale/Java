// Child class that is also abstract
public abstract class DigitalCamera extends Camera {

    public void displayPictureOnScreen() {
        System.out.println("Displaying picture on screen");
    }
}
