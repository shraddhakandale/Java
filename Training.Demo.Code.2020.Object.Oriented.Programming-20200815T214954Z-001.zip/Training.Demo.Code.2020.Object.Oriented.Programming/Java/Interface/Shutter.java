public class Shutter implements ButtonClickListener {

    @Override
    public void onButtonClick() {
        System.out.println("Shutter letting in light rays.");
    }
}
